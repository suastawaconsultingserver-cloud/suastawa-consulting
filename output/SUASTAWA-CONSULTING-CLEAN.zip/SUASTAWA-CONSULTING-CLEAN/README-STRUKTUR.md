# 📦 SUASTAWA CONSULTING — STRUKTUR BERSIH
**Disusun ulang oleh JR Production** · Jakarta Barat
**Domain:** suastawa-consulting.com

> Hasil pembersihan: 262 MB / 19.419 file (banyak sampah .venv & .git) → struktur bersih ini.
> File rahasia (.env asli) TIDAK disertakan di bundle ini demi keamanan.

---

## 🗂️ STRUKTUR

```
SUASTAWA-CONSULTING-CLEAN/
├── backend/                    ← Flask + MongoDB + Cloudinary (deploy ke Railway)
│   ├── app.py                  ← VERSI BARU (244 baris): /api/auth/ganti-password,
│   │                             /api/cloudinary-check, PUT /api/dokumen/<id>
│   ├── requirements.txt
│   ├── railway.toml            ← config deploy (gunicorn, healthcheck /api/health)
│   ├── Procfile
│   └── .env.example            ← TEMPLATE (isi sendiri, jangan commit .env asli)
│
├── frontend/                   ← deploy ke Cloudflare Pages
│   ├── index.html              ← (UPLOAD dari laptop — versi live Cloudinary)
│   ├── admin.html              ← (UPLOAD dari laptop — panel admin)
│   └── _TARUH-DISINI.txt        ← petunjuk
│
├── assets/
│   ├── legalitas/              ← 9 dokumen (Izin KJA, Piagam, izin praktik,
│   │                             sertifikat CA/KP3SKP/PERADI, papan nama)
│   ├── legalitas-baru/         ← 3 sertifikat KKP BARU (belum tayang di web):
│   │   ├── USKP-Tingkat-A.jpeg
│   │   ├── USKP-Tingkat-B.jpeg
│   │   └── Kartu-Kuasa-Hukum-Pengadilan-Pajak.jpeg
│   └── logo/                   ← Logo IAI, IKPI, KJA, KKP + foto papan nama
│
└── docs/                       ← MasterList, Panduan Admin, Panduan Deploy
```

---

## 🔑 STACK & DEPLOY
- **Backend:** Flask di Railway → `suastawa-consulting-production.up.railway.app`
- **Frontend:** Cloudflare Pages (GitHub auto-deploy / `npx wrangler deploy`)
- **DB:** MongoDB Atlas · **Media:** Cloudinary (cloud name `djwrxixt9`)

## ⚠️ CATATAN PENTING (perlu konfirmasi Pak Suastawa)
1. **No. Izin KJA** — live: `357/KM.1/PPPK/2022` vs dokumen lama: `76/KM.1PPPK/2015` (cek mana yg benar)
2. **NPWP** — live: `068615723906000` vs izin praktik: `066615723906000` (beda digit ke-3)
3. **Footer JR Production** — link masih `href="#"`, harus diarahkan ke https://jr-production.com

---
*✦ Made with jr-production.com — Jakarta Barat ✦*
