# 📋 MASTER LIST — WEBSITE KJA & KKP SUASTAWA CONSULTING
**Dibuat oleh:** JR Production  
**Tanggal:** 25 Mei 2026  
**Target Selesai:** 8 Juni 2026  
**MOU:** MOU/JRP/KJA-SWC/20260525051

---

## ✅ DATA YANG SUDAH LENGKAP

### 🏛️ Identitas KJA
- **Nama Resmi:** Kantor Jasa Akuntansi Suastawa Consulting
- **Izin Kemenkeu:** 357/KM.1/PPPK/2022
- **Izin Usaha Awal:** No. 76/KM.1PPPK/2015 (30 Oktober 2015)
- **RNA:** RNA 10235 / Register Negara Akuntan No. D-45.010
- **Alamat:** Jl. Melati No. 14, Banjar Bindu, Mekar Bhuwana, Abiansemal, Badung, Bali 80352
- **WA:** 081338983753
- **Email:** suastawaconsulting@gmail.com
- **Jam Operasional:** Senin–Jumat 08.00–17.00 WITA
- **Berdiri:** 30 Oktober 2015
- **Tagline:** "Your Trusted Partner in Accounting and Tax Compliance"

### 🧾 Identitas KKP
- **Nama Resmi:** Kantor Konsultan Pajak Suastawa Consulting
- **Izin IKPI:** SI-1543/PJ/2008
- **NPWP:** 068615723906000
- **Spesialisasi:** PPh Badan & Perorangan, PPN, Sengketa Pajak

### 👤 Profil Pimpinan
- **Nama:** I Gusti Nyoman Suastawa, S.E., S.H., Ak., CA., BKP
- **Jabatan:** Pemilik / Pemimpin
- **Gelar:** CA (IAI), Ak. (RNA), BKP (IKPI)
- **Register:** RNA 10235 / D-45.010
- **Foto:** ✅ Ada di Piagam RNA (jas hitam, dasi biru)

### 🎨 Aset Visual
- **Logo KJA:** ✅ Logo_KJA_SUASTAWA_CONSULTING.png (simbol S hijau)
- **Logo KKP:** ✅ Logo_KKP_SUASTAWA_CONSULTING.png (dark navy + gold)
- **Logo IAI:** ✅ Logo_IAI.jpeg
- **Logo IKPI:** ✅ Logo_IKPI.jpeg
- **Foto Papan Nama:** ✅ Foto papan IKPI/KKP (WhatsApp_Image_2026-05-24_at_20_12_02.jpeg)
- **Piagam RNA:** ✅ Foto piagam + foto Pak Suastawa
- **Warna Brand:** Hijau KJA #2E7D32 · Biru IAI #0D47A1 · Putih #FFFFFF

### 📝 Konten
- **Profil:** ✅ Sudah ada (±170 kata)
- **Visi Misi:** ✅ Sudah ada
- **Layanan KJA:** ✅ 3 layanan lengkap
- **Testimoni:** ✅ 3 testimoni

---

## ❌ DATA YANG MASIH KURANG (HARUS DIMINTA KE PAK SUASTAWA)

### 📸 Foto Tambahan
| No | Yang Dibutuhkan | Keterangan |
|----|----------------|------------|
| 1 | **Foto tampak luar kantor** (fasad utama) | Resolusi tinggi, siang hari |
| 2 | **Foto ruang kerja/dalam kantor** | Min. 3 foto |
| 3 | **Foto Pak Suastawa** formal (lebih baru) | Untuk halaman "Tim Kami" |
| 4 | **Foto kegiatan konsultasi** dengan klien | Untuk kesan profesional & ramai |
| 5 | **Foto sertifikat & piagam lainnya** | Selain RNA (CA, IKPI, dll.) |

### 📄 Dokumen Tambahan
| No | Yang Dibutuhkan | Keterangan |
|----|----------------|------------|
| 6 | **Izin KKP terbaru** (jika ada pembaruan SI-1543) | Untuk dicantumkan di website |
| 7 | **Sertifikat keanggotaan IAI aktif** | Tahun terbaru |
| 8 | **NPWP KJA** (jika berbeda dari KKP) | Untuk legalitas di footer |

### 📝 Konten Tambahan
| No | Yang Dibutuhkan | Keterangan |
|----|----------------|------------|
| 9 | **Daftar layanan KKP** secara lengkap | Seperti format layanan KJA |
| 10 | **Statistik pencapaian** lebih konkret | Jumlah klien, tahun pengalaman, dll. |
| 11 | **Nama domain final** | kjasuwastawa.com atau suastawaconsulting.com |
| 12 | **Foto/banner artikel blog** (opsional) | Untuk fitur blog perpajakan |

---

## 📌 TO-DO LIST PEMBUATAN WEBSITE

### FASE 1 — PERSIAPAN (Hari 1–2)
- [ ] Konfirmasi nama domain final ke Pak Suastawa
- [ ] Daftarkan domain pilihan
- [ ] Setup hosting
- [ ] Kumpulkan foto tambahan dari Pak Suastawa
- [ ] Convert semua logo ke format PNG transparan

### FASE 2 — DESAIN & STRUKTUR (Hari 3–5)
- [ ] Buat wireframe 1 domain — 2 layanan (KJA & KKP)
- [ ] Desain Hero Section modern dengan foto kantor nyata
- [ ] Struktur navigasi: KJA | KKP | Tentang | Legalitas | Kontak
- [ ] Palet warna: Hijau #2E7D32 + Biru #0D47A1 + Putih
- [ ] Integrasi logo KJA, KKP, IAI, IKPI

### FASE 3 — PENGEMBANGAN (Hari 5–10)
- [ ] **HALAMAN UTAMA (HOME)**
  - Hero dengan tagline + CTA WhatsApp
  - Strip legalitas (IAI · IKPI · Kemenkeu · RNA)
  - Preview layanan KJA & KKP
  - Statistik angka (tahun berdiri, klien, dll.)
  - Testimoni klien
- [ ] **HALAMAN KJA** (layer pertama)
  - Profil KJA
  - Layanan: Pembukuan, Laporan Keuangan, Sistem Akuntansi
  - Legalitas KJA (No. izin, RNA)
- [ ] **HALAMAN KKP** (layer kedua)
  - Profil KKP
  - Layanan: PPh, PPN, Sengketa Pajak
  - Legalitas KKP (IKPI, NPWP)
- [ ] **HALAMAN PROFIL TIM**
  - Foto + gelar lengkap Pak Suastawa
  - Piagam & sertifikasi
- [ ] **HALAMAN LEGALITAS & GALERI**
  - Foto piagam RNA
  - Surat izin Kemenkeu
  - Logo IAI & IKPI
- [ ] **HALAMAN KONTAK**
  - Form konsultasi online
  - Tombol WhatsApp Chat
  - Google Maps Jl. Melati No. 14

### FASE 4 — FITUR TAMBAHAN (Hari 10–12)
- [ ] Tombol WhatsApp floating (selalu terlihat)
- [ ] Google Maps embed koordinat -8.5489650, 115.2308580
- [ ] Form konsultasi → notifikasi ke WA/email
- [ ] Galeri piagam & penghargaan
- [ ] SEO dasar (meta, title, description)
- [ ] SSL/HTTPS aktif
- [ ] Mobile responsive 100%

### FASE 5 — PANEL MASTER / BACKEND (Hari 11–13)
- [ ] Setup admin panel (Netlify CMS / WordPress Admin)
- [ ] 2 section terpisah: KJA admin & KKP admin
- [ ] Kelola konten: edit layanan, tambah artikel, ubah kontak
- [ ] Upload/update foto dari panel
- [ ] Panduan penggunaan panel untuk Pak Suastawa

### FASE 6 — TESTING & LAUNCH (Hari 13–14)
- [ ] Uji coba semua fitur di mobile & desktop
- [ ] Cek semua tombol WhatsApp & form
- [ ] Cek Google Maps berjalan
- [ ] Deploy ke domain final
- [ ] Serah terima + pelatihan penggunaan panel

---

## 🌐 STRUKTUR WEBSITE (1 DOMAIN — 2 LAYANAN)

```
suastawaconsulting.com
│
├── /                    → HOME (landing utama — KJA & KKP)
├── /kja                 → Halaman KJA Suastawa Consulting
│   ├── Profil KJA
│   ├── Layanan KJA
│   └── Legalitas KJA
├── /kkp                 → Halaman KKP Suastawa Consulting
│   ├── Profil KKP
│   ├── Layanan KKP
│   └── Legalitas KKP
├── /tim                 → Profil Tim (I Gusti Nyoman Suastawa)
├── /legalitas           → Galeri Piagam & Sertifikasi
├── /artikel             → Blog Perpajakan & Akuntansi (opsional)
├── /kontak              → Form Kontak + Maps + WA
└── /admin               → Panel Master (login khusus)
    ├── Kelola KJA
    └── Kelola KKP
```

---

## 🎨 REFERENSI DESAIN

**Inspirasi visual yang akan diterapkan:**
- **Layout:** Clean corporate, white space luas, tipografi tegas
- **Hero:** Full-width dengan foto kantor nyata + overlay hijau/biru
- **Warna:** Hijau profesional #2E7D32 + Biru resmi #0D47A1
- **Font:** Inter/Poppins (body) + Playfair Display (heading)
- **Elemen:** Badge legalitas, strip sertifikasi IAI/IKPI, animasi scroll
- **Kesan:** Seperti website firma hukum/akuntan internasional kelas atas

---

## 📞 DATA KONTAK LENGKAP

| | JR Production | KJA & KKP Suastawa |
|---|---|---|
| **Nama** | Adi Guntoro | I Gusti Nyoman Suastawa |
| **WA** | 0859-3922-0519 | 081338983753 |
| **Email** | adi.guntoro1990@gmail.com | suastawaconsulting@gmail.com |
| **Kota** | Jakarta Barat | Badung, Bali |

---

## 💰 RINGKASAN PROYEK

| Item | Detail |
|---|---|
| **Harga Total** | Rp 6.000.000 |
| **DP (Sudah Lunas)** | Rp 3.000.000 |
| **Sisa** | Rp 3.000.000 (setelah selesai) |
| **Durasi** | 14 hari kerja |
| **Deadline** | 8 Juni 2026 |
| **MOU** | MOU/JRP/KJA-SWC/20260525051 |
| **Website Demo** | https://kjasuastawaconsulting.netlify.app/ |

---

*Dokumen ini dibuat oleh JR Production — 25 Mei 2026*
