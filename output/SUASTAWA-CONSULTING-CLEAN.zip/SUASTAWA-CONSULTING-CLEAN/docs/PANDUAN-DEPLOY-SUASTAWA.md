# Panduan Deploy — suastawa-consulting.com

Suastawa bisa di-deploy **2 cara**: otomatis (GitHub) atau manual (Wrangler).
Keduanya menyajikan isi folder `output/`.

---

## STRUKTUR PENTING

```
suastawa_consulting_flow/
├── output/              ← INI yang disajikan jadi website
│   ├── index.html       ← website utama (suastawa-consulting.com)
│   ├── adminsc/         ← panel admin
│   ├── content.md       ← catatan konten (tidak tampil di web)
│   └── seo.md           ← catatan SEO (tidak tampil di web)
├── wrangler.toml        ← directory = ./output
└── src/, tests/, .venv  ← project CrewAI (untuk generate konten, JARANG dipakai)
```

| Item | Nilai |
|---|---|
| Domain | suastawa-consulting.com (+ www) |
| Worker Cloudflare | small-pine-fd8b |
| URL Worker langsung | https://small-pine-fd8b.suastawaconsulting...workers.dev |
| Repo GitHub | suastawaconsultingserver-cloud/suastawa-consulting |
| Folder lokal | Desktop\Project SUASTAWA CONSULTING\suastawa_consulting_flow |
| Folder disajikan | output/ |

> Catatan: `crewai run` di README itu HANYA untuk generate ulang konten dengan AI.
> Untuk update website biasa, TIDAK perlu crewai run — cukup edit `output/` lalu deploy.

---

## CARA 1 — DEPLOY OTOMATIS (GitHub) — DISARANKAN

Tiap `git push`, Cloudflare otomatis publish. Tidak perlu wrangler.

**1. Masuk folder:**
```powershell
cd "$HOME\Desktop\Project SUASTAWA CONSULTING\suastawa_consulting_flow"
```

**2. Salin file baru ke output** (sesuaikan nama file Downloads):

Website:
```powershell
Copy-Item "$HOME\Downloads\index.html" "output\index.html" -Force
```

Admin (kalau ada perubahan — cek dulu nama file di folder adminsc):
```powershell
Copy-Item "$HOME\Downloads\admin.html" "output\adminsc\admin.html" -Force
```

**3. Push ke GitHub → Cloudflare auto-deploy:**
```powershell
git add .
git commit -m "deskripsi perubahan"
git push
```

**4. Tunggu ~1-2 menit**, Cloudflare otomatis publish. Cek di dashboard Cloudflare → Worker `small-pine-fd8b` → Deployments → versi baru muncul.

---

## CARA 2 — DEPLOY MANUAL (Wrangler)

Kalau ingin langsung publish tanpa lewat GitHub.

**1. Masuk folder:**
```powershell
cd "$HOME\Desktop\Project SUASTAWA CONSULTING\suastawa_consulting_flow"
```

**2. Salin file baru** (sama seperti Cara 1 langkah 2)

**3. Deploy langsung:**
```powershell
npx wrangler deploy
```
> Kalau minta `Ok to proceed? (y)`, ketik `y`.
> Berhasil bila muncul: `Deployed small-pine-fd8b triggers`

**4. (Opsional tapi disarankan) simpan juga ke GitHub:**
```powershell
git add .
git commit -m "deskripsi perubahan"
git push
```

---

## CARA MANA YANG DIPAKAI?

- **Cara 1 (GitHub)** — paling rapi, ada riwayat & cadangan. Disarankan untuk update biasa.
- **Cara 2 (Wrangler)** — cepat kalau buru-buru. Tapi jangan lupa push ke GitHub juga, biar GitHub tidak ketinggalan versi.

> PENTING: kalau pakai Cara 2 lalu lupa push ke GitHub, versi di GitHub jadi beda dengan yang live.
> Lalu kalau suatu saat GitHub auto-deploy jalan, bisa menimpa versi live dengan versi lama.
> Maka: **biasakan selalu git push** setelah deploy manual, biar GitHub & live selalu sama.

---

## TIPS (sama seperti Jeroan Bindu)

1. Selalu pakai `Copy-Item` untuk file HTML, JANGAN `Set-Content`/`@"..."@` (rusak encoding).
2. Cek file benar sebelum deploy: `Select-String -Path "output\index.html" -Pattern "kata-kunci"`
3. Tes di Incognito (Ctrl+Shift+N) atau hard-refresh (Ctrl+Shift+R) untuk hindari cache.
4. Ketik perintah satu per satu, jangan tempel banyak baris sekaligus.
5. Cek nama file Downloads dulu: `dir "$HOME\Downloads\index*.html"`
