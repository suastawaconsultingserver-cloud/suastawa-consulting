# Panduan Penggunaan Panel Admin — Suastawa Consulting

Selamat datang! Panduan ini membantu Anda mengelola website
suastawa-consulting.com sendiri, tanpa perlu bantuan teknis.

---

## CARA MASUK (LOGIN)

1. Buka browser (Chrome/Safari), ketik alamat: **suastawa-consulting.com/adminsc/admin**
2. Masukkan **Username** dan **Password** Anda
3. Klik tombol **Masuk**

> Tips: simpan alamat ini di bookmark agar mudah dibuka lagi.
> Jika lupa password, hubungi JR Production.

---

## MENGENAL MENU (di sisi kiri layar)

| Menu | Fungsi |
|---|---|
| 📊 **Dashboard** | Halaman utama — ringkasan website |
| ⚙️ **Layanan KJA/KKP** | Kelola daftar layanan yang ditawarkan |
| 📁 **Dokumen & Sertifikat** | Upload & kelola dokumen/sertifikat |
| ✉️ **Pesan Masuk** | Lihat pesan dari pengunjung website |
| 💬 **Live Chat** | Buka dashboard chat langsung (Tawk.to) |
| 🔧 **Pengaturan** | Info sistem + Ganti Password |

---

## CARA MENAMBAH / EDIT LAYANAN

1. Klik menu **⚙️ Layanan KJA/KKP**
2. Klik tombol **+ Tambah** untuk layanan baru
3. Isi nama layanan, kategori, dan deskripsi
4. Klik **Simpan**
5. Layanan langsung muncul di website

> Untuk mengubah: klik **Edit** pada layanan. Untuk menghapus: klik **Hapus**.

---

## CARA UPLOAD DOKUMEN / SERTIFIKAT

1. Klik menu **📁 Dokumen & Sertifikat**
2. Klik tombol **Upload**
3. Pilih file (PDF/gambar) dari perangkat Anda
4. Isi nama dokumen & kategori
5. Klik **Simpan** (tunggu sebentar saat upload)

> Dokumen tersimpan aman di cloud dan bisa ditampilkan di website.

---

## CARA MELIHAT PESAN MASUK

1. Klik menu **✉️ Pesan Masuk**
2. Daftar pesan dari pengunjung muncul (yang baru ditandai khusus)
3. Klik pesan untuk membaca
4. Bisa ditandai sudah dibaca

> Pesan dari form kontak website otomatis masuk ke sini.

---

## LIVE CHAT (Tawk.to)

1. Klik menu **💬 Live Chat**
2. Dashboard Tawk.to akan terbuka di tab baru
3. Di sana Anda bisa membalas chat pengunjung secara langsung

> Tawk.to adalah layanan chat terpisah. Login dengan akun Tawk.to Anda.

---

## CARA GANTI PASSWORD

1. Klik menu **🔧 Pengaturan**
2. Scroll ke bagian **🔑 Ganti Password**
3. Masukkan password lama
4. Masukkan password baru (minimal 6 karakter)
5. Masukkan konfirmasi password baru (ulangi yang sama)
6. Klik **Simpan Password Baru**

> Gunakan password yang kuat & mudah diingat. Jangan dibagikan.

---

## CEK KONEKSI SISTEM

Di menu **🔧 Pengaturan**, ada tombol **🔌 Cek Koneksi API**.
Klik untuk memastikan website terhubung dengan baik ke sistem.
Jika muncul "✅ Online", berarti semua normal.

---

## PERTANYAAN UMUM

**T: Apakah saya perlu hal teknis setiap update?**
J: TIDAK. Semua lewat panel admin langsung tersimpan & tampil di website.

**T: Perubahan tidak muncul di website?**
J: Refresh halaman (Ctrl+Shift+R di komputer), atau tunggu beberapa detik.

**T: Lupa password?**
J: Hubungi JR Production untuk reset.

---

## BUTUH BANTUAN?

Hubungi **JR Production** — tim pengembang website Anda.
Kami siap membantu jika ada kendala.

---

*Panduan ini dibuat oleh JR Production untuk kemudahan Anda.*
